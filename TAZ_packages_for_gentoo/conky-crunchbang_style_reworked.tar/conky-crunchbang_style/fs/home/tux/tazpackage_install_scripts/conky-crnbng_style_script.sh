##########################################################################
#        conky-crunchbang_style installation script for gentoo           #
# made by ?, released under the GNU General Public License v3.0          #
##########################################################################

# type "touch scriptname.sh" in the terminal, followed by
# "chmod+x scriptname.sh" to make this script executable
# then, type "./scriptname.sh" to execute the script

#!/bin/sh

cd /var/lib/vnstat-1.14
make
make install
vnstat --create -i eth0
	
cat << EOF | sudo tee /etc/xdg/openbox/autostart/autostart.sh
# vnstat
vnstat &

#to remove the conky-crnbng_style package, type the following:
#cd /etc/xdg/openbox/autostart/
#sed -i ‘s/# vnstat
#vnstat &/# autostart.sh
