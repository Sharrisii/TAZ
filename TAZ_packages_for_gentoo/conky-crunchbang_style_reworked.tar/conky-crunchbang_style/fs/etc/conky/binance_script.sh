#!/usr/bin/python
#
# Fetches currency rates info from binance
# no api key needed, if a key becomes needed later on, retrieve key from currency_rates_api_key.sh on
# optional USB stick


url: https://api.binance.com/api/v1/ticker/allPrices
