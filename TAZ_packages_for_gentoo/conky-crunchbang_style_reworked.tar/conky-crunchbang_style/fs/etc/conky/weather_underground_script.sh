#!/usr/bin/python
#
# Fetches Weather info from Weather Underground
#
# Usage: ./wundergound.py zipcode
#
# International:
#  * Go to http://www.wunderground.com/
#  * Find your city
#  * Click the RSS icon
#  * Station ID is the number that follows /stations/ in the url
#
# Values are either True or False
#
# Script made by pyther

# Needs to be altered ! -->
#I would like the text output to be:
#temperature, humidity, condition
#output temperature should be in °C, not °F
#
#I'd like one forecast (for tomorrow)
#Next, I would like forecasts for tomorrow for several places, knowingly:
#Shanghai, China ( I31CHANG7 )
#New Delhi, India (IDELHINE9 )
#New York, USA (KNYNEWYO639)
#Brussels, Belgium (IBRUSSEL37)
#Moscow, Russia (IMOSKVA347)
#Mexico City, Mexico  (IDFCOLON8)
#Tokyo, Japan (I13HATCH4)

# Also: set script to retrieve api key for weather underground from the optional usb stick:
#weather_underground_api_key.sh

metric=False
international=False

import sys
import feedparser

def usage():
    print("Usage:")
    if international:
        print("  ./wunderground.py StationID")
    else:
        print("  ./weunderground.py zipcode")
    sys.exit(1)

if not len(sys.argv) == 2:
    usage()

location=sys.argv[1]

if international:
    url="http://rss.wunderground.com/auto/rss_full/global/stations/"
else:
    url="http://rss.wunderground.com/auto/rss_full/"

feed=feedparser.parse(url+location)

if not feed.feed:
    # Assume Error
    print("Error")
    sys.exit(1)

current=feed['items'][0].title

if metric:
    temp=current.split(",")[0].split(":")[1].split("/")[1].strip()
else:
    temp=current.split(",")[0].split(":")[1].split("/")[0].strip()

condition=current.split(",")[1].split("-")[0].strip()

print(temp, "-", condition)