#!/usr/bin/python
#
# Fetches currency rates info from fixer.io
# no api key needed, if a key becomes needed later on, retrieve key from currency_rates_api_key.sh on
# optional USB stick


url: http://api.fixer.io/