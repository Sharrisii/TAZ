##########################################################################
#         gajim-OTR installation script for gentoo	                     #
# made by ?, released under the GNU General Public License v3.0          #
##########################################################################

# type "touch scriptname.sh" in the terminal, followed by
# "chmod+x scriptname.sh" to make this script executable
# then, type "./scriptname.sh" to execute the script

#!/bin/sh

tazpkg get-install pycrypto

cd /usr/share/gajim/plugins/pure-python-otr-master
sudo python setup.py install

#to remove the gajim-OTR package, type the following:
#cd /usr/share/gajim/
#rm -rf plugins
#tazpkg remove pycrypto
