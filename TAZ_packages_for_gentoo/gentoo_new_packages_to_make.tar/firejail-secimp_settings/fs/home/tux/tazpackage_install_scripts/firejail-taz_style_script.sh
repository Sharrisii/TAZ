##########################################################################
#    firejail-secimp_settings installation script for gentoo             #
# made by ?, released under the GNU General Public License v3.0          #
##########################################################################

# type "touch scriptname.sh" in the terminal, followed by
# "chmod+x scriptname.sh" to make this script executable
# then, type "./scriptname.sh" to execute the script

#!/bin/sh

#to remove the firejail-secimp_settings package, type the following:
#cd /etc/xdg/openbox/autostart/
#sed -i ‘s/# firejail palemoon
##firejail ./etc/firejail/palemoon.profile" &
## firejail gajim
#firejail ./etc/firejail/gajim.profile" &/# autostart.sh

cat << EOF | sudo tee /etc/xdg/openbox/autostart/autostart.sh
	# firejail palemoon
	firejail ./etc/firejail/palemoon.profile" &
	
	# firejail gajim
	firejail ./etc/firejail/gajim.profile" &



	cd /etc/xdg/openbox/autostart/
	sed -i ‘s/# firejail palemoon
	firejail ./etc/firejail/palemoon.profile" &
	
	# firejail gajim
	firejail ./etc/firejail/gajim.profile" &/# autostart.sh
